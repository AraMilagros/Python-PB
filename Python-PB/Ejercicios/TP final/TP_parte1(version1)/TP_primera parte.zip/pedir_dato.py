import re
#re.search no regresa un boolean...
#devuelve un objeto de coincidencia o None de lo contrario

def contiene_numero(n):
    if re.search('[0-9]', n):
        return True #Si contiene numeros
    else:
        return False #No contiene numeros

def validar_texto(txt):
    return not(contiene_numero(txt)) and len(txt)>0

def pedir_dato(mensaje, func):
    entrada=input(mensaje)
    while not func(entrada):
        entrada=input(mensaje)
    return entrada

print(pedir_dato('ingrese algo: ', validar_texto))

